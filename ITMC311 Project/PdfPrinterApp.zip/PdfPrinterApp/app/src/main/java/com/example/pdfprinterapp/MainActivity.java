package com.example.pdfprinterapp;

import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    Button btnPrint, btnSave, btnPrintNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        btnPrint = findViewById(R.id.btnPrint);
        btnSave = findViewById(R.id.btnSave);
        btnPrintNow = findViewById(R.id.btnPrintNow);

        webView.getSettings().setJavaScriptEnabled(true);

        loadPdfIntoWebView();

        // زر فتح نافذة الطباعة (يمكن تختار طابعة أو حفظ PDF)
        btnPrint.setOnClickListener(v -> {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            printManager.print("طباعة PDF", webView.createPrintDocumentAdapter("MyPDF"), new PrintAttributes.Builder().build());
        });

        // زر حفظ PDF (عرض رسالة توجيه)
        btnSave.setOnClickListener(v -> {
            Toast.makeText(this, "لا يمكن الحفظ مباشرة. استخدم زر الطباعة واختر 'Save as PDF' من نافذة الطباعة.", Toast.LENGTH_LONG).show();
        });

        // زر اطبع الآن (يطبع نص بسيط فورًا بدون عرض PDF)
        btnPrintNow.setOnClickListener(v -> {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);

            // إنشاء طابعة تطبع نص تجريبي
            PrintDocumentAdapter adapter = new PrintDocumentAdapter() {
                @Override
                public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                     android.os.CancellationSignal cancellationSignal,
                                     LayoutResultCallback callback, Bundle extras) {
                    callback.onLayoutFinished(
                            new android.print.PrintDocumentInfo.Builder("test_print.pdf")
                                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                    .build(), true);
                }

                @Override
                public void onWrite(android.print.PageRange[] pages,
                                    android.os.ParcelFileDescriptor destination,
                                    android.os.CancellationSignal cancellationSignal,
                                    WriteResultCallback callback) {
                    try {
                        String text = "هذا نص تجريبي للطباعة الفورية من التطبيق.\nطباعة الآن!";
                        byte[] bytes = text.getBytes();
                        java.io.FileOutputStream out = new java.io.FileOutputStream(destination.getFileDescriptor());
                        out.write(bytes);
                        out.close();
                        callback.onWriteFinished(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES});
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };

            printManager.print("طباعة فورية", adapter, new PrintAttributes.Builder().build());
        });
    }

    // تحميل ملف PDF من assets وعرضه في WebView
    private void loadPdfIntoWebView() {
        try {
            InputStream inputStream = getAssets().open("s.pdf");
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();

            String encodedPdf = Base64.encodeToString(buffer, Base64.NO_WRAP);

            String html = "<html><body style='margin:0;padding:0;'>" +
                    "<iframe width='100%' height='100%' " +
                    "src='data:application/pdf;base64," + encodedPdf + "'></iframe>" +
                    "</body></html>";

            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);

        } catch (Exception e) {
            Toast.makeText(this, "فشل تحميل الملف", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}